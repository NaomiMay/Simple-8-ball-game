// Array holding the different images of the 8-ball in various states
var rotationImages = [
  "images/8-ball-1.png",
  "images/8-ball-2.png",
  "images/8-ball-3.png",
  "images/8-ball-4.png",
  "images/8-ball-5.png",
];

var ballImage = document.getElementById("ball"); // Get the ball image element by its ID and assign it to a new variable

const shakebtn = document.getElementById("q-button"); // Get the question button element by its ID and assign it to a new variable

shakebtn.addEventListener("click", () => {
  // Add a click event listener to the 'shakebtn' (the question button)
  shakebtn.disabled = true; // Disable the button to stop multiple clicks or self clicks
  ballImage.classList.remove("shake"); // Remove the shake class to reset any existing animations

  void ballImage.offsetWidth; // Force reflow to make sure the animation gets reapplied

  ballImage.classList.toggle("shake"); // Add the shake class back to trigger the shake animation

  setTimeout(() => {
    // Set a timeout to perform actions after the animation is completed
    ballImage.classList.remove("shake"); // Remove the shake class after 1 second
    changeBallImg(); // Change the ball image using function
    shakebtn.disabled = false; // Re-enable the shake button to be used
  }, 1000); // Timeout duration of 1 second
});

function changeBallImg() {
  // Function to change the ball image by random selection from array
  var randomSelection = Math.floor(Math.random() * rotationImages.length);
  /* Generate a random index between 0 and the length of the rotationImages array.
     This selects a random image from the array */

  ballImage.src = rotationImages[randomSelection];
  /* Change the source of the ball image element to the randomly selected image from the array*/
}
